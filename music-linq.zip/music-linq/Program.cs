﻿using System;
using System.Collections.Generic;
using System.Linq;
using JsonData;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //Collections to work with
            List<Artist> Artists = JsonToFile<Artist>.ReadJson();
            List<Group> Groups = JsonToFile<Group>.ReadJson();
  


            //There is only one artist in this collection from Mount Vernon, what is their name and age?
            // var person = Artists.Where(a=>a.Hometown == "Mount Vernon");
            // foreach (var item in person)
            // {
            //     System.Console.WriteLine("********************");
            //     System.Console.WriteLine(item.ArtistName);
            //     System.Console.WriteLine(item.Age);
            //     System.Console.WriteLine("********************");
            // }
          

//    ******************************************************************************************             
            // var person = Artists.OrderByDescending(a=>a.Age).Last();
            // System.Console.WriteLine(person.ArtistName);

            //Who is the youngest artist in our collection of artists?
//    ******************************************************************************************  
            //Display all artists with 'William' somewhere in their real name
            
//    ******************************************************************************************  
            //Display the 3 oldest artist from Atlanta
//    ******************************************************************************************         
            // var persons =Artists.Where(a =>a.RealName.Contains("William"));
            // foreach (var item in persons)
            // {
            //    System.Console.WriteLine(item.RealName);
            // }
            //(Optional) Display the Group Name of all groups that have members that are not from New York City
         
            // var persons = 
            //     from a in Artists
            //     join g in Groups on a.GroupId
            //     equals g.Id 
            //     select new
            //     {
            //         Artists.GroupId = a .GroupId,
            //         GroupID = g.Id
            //     };
            

            // var query = 
            // (from g in Groups
            // join a in Artists.Where(a=>a.Hometown != "New York City")
            // on g.Id equals a.GroupId
            // select new {g.GroupName}).Distinct();


            //  foreach (var item in query)
            // {
            //     System.Console.WriteLine(item.GroupName);
            // }


                


            //(Optional) Display the artist names of all members of the group 'Wu-Tang Clan'

            var query2  = 
            from g in Groups.Where(g=>g.GroupName == "Wu-Tang Clan")
            join a in Artists on g.Id equals a.GroupId
            select new {a.ArtistName};

            foreach (var item in query2)
            {
                System.Console.WriteLine(item.ArtistName);
            }










        }
    }
}
