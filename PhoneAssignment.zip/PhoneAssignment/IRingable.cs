using System;

namespace PhoneAssignment{

        public interface IRingable{

            string Ring();
            string Unlock();


        }

}