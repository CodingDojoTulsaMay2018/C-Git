
using System.Collections.Generic;
namespace ModelFun.Models
{
    public class IntArray
    {
        public int[] intArray{ get; set; }
        
     
    }
}