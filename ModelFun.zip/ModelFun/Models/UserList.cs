using System.Collections.Generic;
namespace ModelFun.Models
{
    public class UserList
    {
        public List<string> listOfUsers{ get; set; }
        
     
    }
}