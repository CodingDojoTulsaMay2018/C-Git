namespace ModelFun.Models
{
    public class StringText
    {
        public string Sometext{ get; set; }
        
     
    }
}